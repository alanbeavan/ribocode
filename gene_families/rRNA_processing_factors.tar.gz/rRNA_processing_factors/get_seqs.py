#!/usr/bin/env python3
"""Get the relevant fields from the APs including name and sequence."""

import time
import requests as r
from Bio import SeqIO
from io import StringIO
import my_module as mod


def get_data(baseUrl, uid):
    """Get the data using biomart."""
    currentUrl= baseUrl + uid + ".fasta"
    response = r.post(currentUrl)
    cData=''.join(response.text)
    cData = '__'.join(cData.split(","))
    seq="".join(cData.split("\n")[1:]).strip()
    header = "".join(cData.split("\n")[:1]).strip()[1:]
    return [header, seq]

def main():
    """Do the things."""
    newlines = ["small_yeast_name,yeast_name,yeast_uniprot_id,yeast_uniprot_header,yeast_sequence,small_human_name,human_name,human_uniprot_id,human_uniprot_header,human_sequence"]
    baseUrl="http://www.uniprot.org/uniprot/"
    for line in mod.get_file_data("ids.csv")[1:]:
        fields = line.split(",")
        if fields[0]:
            og_yeast_name = fields[0]
            yeast_id = fields[1]
            yeast_header, yeast_seq = get_data(baseUrl, yeast_id)
            try:
                yeast_name = yeast_header.split("YEAST ")[1].split(" OS=")[0]
            except:
                yeast_name = ""
        else:
            og_yeast_name = ""
            yeast_id = ""
            yeast_name = ""
            yeast_sequence = ""
            yeast_name = ""
            yeast_header = ""
        if fields[2]:
            og_human_name = fields[2]
            human_id = fields[3]
            human_header, human_seq = get_data(baseUrl, human_id)
            try:
                human_name = human_header.split("HUMAN ")[1].split(" OS=")[0]
            except:
                human_name = ""
        else:
            og_human_name = ""
            human_id = ""
            human_name = ""
            human_seq = ""
            human_name = ""
            human_header = ""

        newlines.append(",".join([og_yeast_name, yeast_name, yeast_id, yeast_header, yeast_seq, og_human_name, human_name, human_id, human_header, human_seq]))
        print(len(newlines))
        time.sleep(1)
    with open("full_table.csv", "w", encoding = "utf8") as out:
        out.write("\n".join(newlines) + "\n")




if __name__ == "__main__":
    main()
