#!/usr/bin/env python3.6
"""Docstring."""

import my_module as mod

def main():
    """Do the things."""
    for line in mod.get_file_data("full_table.csv")[1:]:
        fields = line.split(",")
        if fields[0]:
            with open("seed_seqs/" + fields[2] + ".fa", "w", encoding = "utf8") as out:
                out.write(">" + fields[3] + "\n" + fields[4] + "\n")
                if fields[5]:
                    out.write(">" + fields[8] + "\n" + fields[9] + "\n")
        elif fields[5]:
            with open("seed_seqs/" + fields[7] + ".fa", "w", encoding = "utf8") as out:
                out.write(">" + fields[8] + "\n" + fields[9] + "\n")


if __name__ == "__main__":
    main()
