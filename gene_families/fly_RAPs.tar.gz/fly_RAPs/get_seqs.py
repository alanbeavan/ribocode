#!/usr/bin/env python3.6
"""Docstring."""

import my_module as mod

def main():
    """Do the things."""
    for line in mod.get_file_data("fly_raps_table.csv")[1:]:
        fields = line.split(",")
        with open("families/" + fields[1] + ".fa", "w", encoding = "utf8") as out:
            out.write(">" + fields[0] + "\n" + fields[3] + "\n")

if __name__ == "__main__":
    main()
