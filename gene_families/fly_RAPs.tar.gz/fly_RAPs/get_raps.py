#!/usr/bin/env python3
"""Get the relevant fields from the APs including name and sequence."""

import time
import requests as r
from Bio import SeqIO
from io import StringIO
import my_module as mod

def main():
    """Do the things."""
    newlines = ["name,uniprot_id,uniprot_header,sequence"]
    baseUrl="http://www.uniprot.org/uniprot/"
    for line in mod.get_file_data("fly_rap_ids.csv")[1:]:
        fields = line.split("  ")
        print(fields)
        cID = fields[0]
        currentUrl=baseUrl+cID+".fasta"
        response = r.post(currentUrl)
        cData=''.join(response.text)
        cData = '__'.join(cData.split(","))
        seq="".join(cData.split("\n")[1:]).strip()
        header = "".join(cData.split("\n")[:1]).strip()[1:]
        try:
            name = header.split("DROME ")[1].split(" OS=")[0]
        except:
            name = ""
            print(header)
        newlines.append(",".join([name, cID, header, seq]))
        print(len(newlines))
        time.sleep(1)
    with open("fly_raps_table.csv", "w", encoding = "utf8") as out:
        out.write("\n".join(newlines) + "\n")




if __name__ == "__main__":
    main()
